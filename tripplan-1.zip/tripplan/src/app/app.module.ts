import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WelcomeComponent } from './component/welcome/welcome.component';
import { HomeComponent } from './component/home/home.component';
import { CreateaccountComponent } from './component/createaccount/createaccount.component';
import { ForgotpasswordComponent } from './component/forgotpassword/forgotpassword.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { FooterComponent } from './component/footer/footer.component';
import { ProfileComponent } from './component/profile/profile.component';
import { AdminoperationsComponent } from './component/adminoperations/adminoperations.component';
import { AdminloginComponent } from './component/adminoperations/adminlogin/adminlogin.component';
import { AdminhomeComponent } from './component/adminoperations/adminhome/adminhome.component';

import { Location } from '@angular/common';
import { WishlistComponent } from './component/wishlist/wishlist.component';
import { ExploretripsComponent } from './component/exploretrips/exploretrips.component';
import { ManagetripsComponent } from './component/adminoperations/managetrips/managetrips.component';
import { ViewuserComponent } from './adminoperations/viewuser/viewuser.component';
import { AddtripsComponent } from './adminoperations/addtrips/addtrips.component';
import { UpdatetripComponent } from './adminoperations/updatetrip/updatetrip.component';
import { UpdateuserComponent } from './adminoperations/updateuser/updateuser.component';
import { BookyourtripComponent } from './component/bookyourtrip/bookyourtrip.component';
import { BooktripComponent } from './component/booktrip/booktrip.component';
import { SuccessComponent } from './component/success/success.component';
import { ManagebookingsComponent } from './adminoperations/managebookings/managebookings.component';


@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    HomeComponent,
    CreateaccountComponent,
    ForgotpasswordComponent,
    FooterComponent,
    ProfileComponent,
    AdminoperationsComponent,
    AdminloginComponent,
    AdminhomeComponent,
    WishlistComponent,
    ExploretripsComponent,
    ManagetripsComponent,
    ViewuserComponent,
    AddtripsComponent,
    UpdatetripComponent,
    UpdateuserComponent,
    BookyourtripComponent,
    BooktripComponent,
    SuccessComponent,
    ManagebookingsComponent,
  

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [Location],
  bootstrap: [AppComponent]
})
export class AppModule { }
