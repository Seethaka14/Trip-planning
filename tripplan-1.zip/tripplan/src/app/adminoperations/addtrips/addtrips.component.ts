import { Component, OnInit } from '@angular/core';
import { Trip } from '../../model/trip';
import { Router } from '@angular/router';
import { TripserviceService } from '../../service/tripservice.service';

@Component({
  selector: 'app-addtrips',
  standalone: false,
  templateUrl: './addtrips.component.html',
  styleUrl: './addtrips.component.css'
})
export class AddtripsComponent implements OnInit{
  trip = new Trip();
  tripId:any;
  trips: Trip[] = [];
  constructor(private router:Router,private tripService:TripserviceService){}
ngOnInit(): void {
}

addTrip(trip:any): void {
  this.tripService.addTrip(this.trip).subscribe(
    (Response:any)=>{
      this.trips=Response;
      alert("Trip added Successfully!!")
      this.router.navigate(['managetrip'])
    }
  )

}


  backToAdminHome(): void {
    const adminName = localStorage.getItem('adminName') || '';
    this.router.navigate(['/adminhome', adminName]);
  }
}



