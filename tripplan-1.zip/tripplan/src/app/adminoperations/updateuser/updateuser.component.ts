import { Component, OnInit } from '@angular/core';
import { UserDataService } from '../../service/user-data.service';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from '../../model/User';

@Component({
  selector: 'app-updateuser',
  standalone: false,
  templateUrl: './updateuser.component.html',
  styleUrl: './updateuser.component.css'
})
export class UpdateuserComponent implements OnInit{
  constructor(private userService:UserDataService,private router:Router,private route:ActivatedRoute){}
  user =new User();
  userId:any;
  userForm:any;

  ngOnInit(): void {
    this.userId=this.route.snapshot.paramMap.get('userId')
    this.userService.getUserById(this.userId).subscribe(
      (response:any)=>{
        this.user=response;
      }
    )
  }
  updateUser(){
    this.userService.updateUserById(this.userId,this.user).subscribe(
      (response:any)=>{
        alert("updated successfully!!")
        this.router.navigate(['viewusers'])
      }
    )

  }

}
