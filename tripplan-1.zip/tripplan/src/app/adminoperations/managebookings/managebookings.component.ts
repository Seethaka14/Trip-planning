import { Component, OnInit } from '@angular/core';
import { TouristserviceService } from '../../service/touristservice.service';
import { Tourist } from '../../model/Tourist';

@Component({
  selector: 'app-managebookings',
  standalone: false,
  templateUrl: './managebookings.component.html',
  styleUrl: './managebookings.component.css'
})
export class ManagebookingsComponent implements OnInit{
  tourist = new Tourist();
  tourists:any;
  constructor(private touristService:TouristserviceService){}
  
  ngOnInit(): void {
    this.touristService.getAllTourists().subscribe(
      (response: any) => {
        this.tourists = response.map((tourist: any) => {
          // Ensuring each tourist has the trip data populated correctly
          if (!tourist.trip) {
            tourist.trip = null;
          }
          return tourist;
        });
      },
      (error) => {
        console.error('Error fetching tourists:', error);
      }
    );
  }
 

}
