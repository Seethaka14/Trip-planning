import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../../model/User';
@Component({
  selector: 'app-home',
  standalone: false,
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements OnInit{
  user=new User();
  firstName:string="";
  lastName:string="";

constructor(private router:Router){}
ngOnInit(): void {
  this.firstName=sessionStorage.getItem('firstName')||'';
  this.lastName=sessionStorage.getItem('lastName')||'';
}

manageProfile() {
  const userId = sessionStorage.getItem('userId'); // or get from auth/user service
  if (userId) {
    this.router.navigate(['profile']);
  } else {
    alert('User not logged in');
  }
}

logout(){
  sessionStorage.removeItem('userId');
  this.router.navigate(['login']);
}
wishlist() {
  const userId = sessionStorage.getItem('userId');
  if (userId) {
    this.router.navigate(['wishlist']); // Navigate to wishlist page
  } else {
    alert('User not logged in');
  }
}

exploreTrips(){
  this.router.navigate(['trips']);
}
Bookyourtrip(){
  this.router.navigate(['bookyourtrip']);
}
}
