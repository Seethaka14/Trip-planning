import { Component, OnInit } from '@angular/core';
import { User } from '../../model/User';
import { UserDataService } from '../../service/user-data.service';
import { LoginService } from '../../service/login.service';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
@Component({
  selector: 'app-profile',
  standalone: false,
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent implements OnInit {
  user =new User();
  find=this.user;
  userId:any;
  copass :any;
  isFirstNameValid:Boolean=true;
  isLastNameValid:Boolean=true;
  isEmailVaild:Boolean=true;
  isAddressValid:Boolean=true;
  isMobileValid: Boolean = true;
  isPasswordValid: Boolean = true;
  constructor(private location:Location,private userDataService:UserDataService,public loginService:LoginService,private router:Router){}
  ngOnInit(): void {
    if (!this.loginService.isUserLoggedin()) {
      alert('User not logged in');
      this.router.navigate(['login']); // Redirect to login if the user is not logged in
      return;
    }
  
    this.userId = sessionStorage.getItem('userId');
    this.userDataService.getUserById(this.userId).subscribe(
      (Response: any) => {
        console.log(Response);
        this.user = Response;
      },
      (error) => {
        console.error('Error loading user data:', error);
      }
    );
  }
  
update(email: string,password: string) {
  console.log("hi")
  if (this.copass == password) {
    this.userDataService.updateUserByEmail(email,this.user).subscribe(

      (Response:any) => { 
        console.log("Updated");
        console.log(Response);
        this.router.navigate(['home', this.userId]) 
      }
    )
  } else {
    alert("PASSWORD DOES NOT MATCH CONFIRM PASSWORD")
  }

}
goBack(): void {
  this.location.back(); // This will navigate to the previous page
}
userMobileNoValid(event: any) {
  event.target.value = event.target.value.trim();
  var mobile = event.target.value
  let m = mobile.split("");
  console.log(m)
  let n = new Set(m);
  console.log(new Set(m));
  console.log(n.size)

  this.isMobileValid = mobile.match(/^(0|91)?[6-9][0-9]{9}$/) && n.size > 2 ? true : false
  console.log(this.isMobileValid)
}
passwordValid(event: any) {
  event.target.value = event.target.value.trim();
  var pass = event.target.value
  this.isPasswordValid = pass.match("^[a-zA-Z0-9._-]+[@|_|&|%|*|$|-][a-zA-Z0-9-]{2,5}$") ? true : false
  console.log(this.passwordValid)
}
firstNameValid(event:any){
  event.target.value=event.target.value.trim();
  var fname=event.target.value
  this.isFirstNameValid=fname.match("^[A-Za-z]{2,30}$")? true:false
  console.log(this.firstNameValid)
}
lastNameValid(event:any){
  event.target.value=event.target.value.trim();
  var lastNamename=event.target.value
  this.isLastNameValid=lastNamename.match("^[A-Za-z]{2,30}$")? true:false
  console.log(this.lastNameValid)
}
addressValid(event:any){
  event.target.value=event.target.value.trim();
  var address=event.target.value
  this.isAddressValid=address.match("^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\.[a-zA-Z.]{2,4}$")? true:false
  console.log(this.addressValid)
}
emailValid(event:any){
  event.target.value=event.target.value.trim();
  var mail=event.target.value
  this.isAddressValid=mail.match("^[a-zA-Z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")? true:false
  console.log(this.emailValid)
}
}
