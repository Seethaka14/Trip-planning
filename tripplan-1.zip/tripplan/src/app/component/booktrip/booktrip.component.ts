import { Component, OnInit } from '@angular/core';
import { Trip } from '../../model/trip';
import { ActivatedRoute, Router } from '@angular/router';
import { TripserviceService } from '../../service/tripservice.service';
import { UserDataService } from '../../service/user-data.service';
import { User } from '../../model/User';
import { Tourist } from '../../model/Tourist';
import { TouristserviceService } from '../../service/touristservice.service';
import { BankserverService } from '../../service/bankserver.service';

@Component({
  selector: 'app-booktrip',
  standalone: false,
  templateUrl: './booktrip.component.html',
  styleUrl: './booktrip.component.css'
})
export class BooktripComponent implements OnInit{
  trip = new Trip();
  user = new User();
  tourist = new Tourist();
  tripId: any;
  userId: any;
  paymentMethod: string = '';
  cardNumber: string = '';
  expiryDate: string = '';
  cvv: string = '';
  upiId: string = '';
  paymentId: string = '';  // Store the generated payment ID
  totalAmount:number=0;
  
  // Flag to show payment options
  showPaymentOptions: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private tripService: TripserviceService,
    private userService: UserDataService,
    private touristService: TouristserviceService,
    private bankServer:BankserverService,
    private router:Router
  ) {}

  ngOnInit(): void {
    this.tripId = this.route.snapshot.paramMap.get('tripId');
    this.userId = sessionStorage.getItem('userId');

    // Fetch user details
    this.userService.getUserById(this.userId).subscribe((response: any) => {
      this.user = response;
    });

    // Fetch trip details
    this.tripService.getTripById(this.tripId).subscribe((response: any) => {
      this.trip = response;
    });
  }

  // This function triggers when the user clicks on "Proceed to Payment"
  proceedToPayment(): void {
    this.showPaymentOptions = true;
    this.totalAmount=this.trip.budget;
  }

  // Handle selecting a payment method
  selectPaymentMethod(method: string): void {
    this.paymentMethod = method;
  }

  // This function processes the payment

  processPayment(): void {
    if (this.paymentMethod === 'cards') {
      this.bankServer.getCardDetailsbyCNumCVVD(this.cardNumber, this.cvv, this.expiryDate)
        .subscribe(
          (response: any) => {
            if(response == null){
              alert("please enter the valid card details")
            }
            else{
            console.log('Card verified successfully:', response);
            this.paymentId = 'CARD-' + Math.random().toString(36).substr(2, 9); // generate payment ID
            this.bookTrip();
            }
          },
          (error: any) => {
            console.error('Invalid card details', error);
            alert('Invalid Card Details. Please check your card number, expiry date, or CVV.');
          }
        );
  
    }
     else if (this.paymentMethod === 'upi') {
      // 🔥 Call BankserverService to validate UPI
      this.bankServer.getUpi(this.upiId)
        .subscribe(
          (response: any) => {
            if(response==null){
              alert("please enter valid UPI ID")
            }
            else{
            console.log('UPI verified successfully:', response);
            this.paymentId = 'UPI-' + Math.random().toString(36).substr(2, 9); // generate payment ID
            this.bookTrip(); // Proceed after UPI verified
            }
          },
          (error: any) => {
            console.error('Invalid UPI ID', error);
            alert('Invalid UPI ID. Please check your UPI address.');
          }
        );
  
    } else {
      alert('Please select a payment method');
      return;
    }
  }
  
  // This function saves the tourist data after successful payment
  bookTrip(): void {
    // Set tourist details
    this.tourist.tFirstName = this.user.firstName;
    this.tourist.tLastName = this.user.lastName;
    this.tourist.tEmail = this.user.email;
    this.tourist.tMobileNo = this.user.userMobileNo;
    this.tourist.tAge = this.user.userAge;
    this.tourist.tGender = this.user.userGender;
    this.tourist.trip = this.trip;  // Assign selected trip to tourist
    this.tourist.paymentId = this.paymentId;  // Attach the payment ID to the tourist record

    // Send tourist data to backend with the payment ID
    this.touristService.addTouristToTrip(this.tripId, this.tourist).subscribe(
      (response: any) => {
        console.log('Tourist booked successfully', response);
        alert('Payment successful and trip booked!');
        this.router.navigate(['success'])
        // Optionally redirect or show a success message
      },
      (error: any) => {
        console.error('Error booking tourist', error);
        alert('Error during payment or booking. Please try again.');
      }
    );
  }


  // Card number validation (only allow 16 digits)
onCardNumberInput(event: any) {
  const input = event.target;
  input.value = input.value.replace(/\D/g, '').slice(0, 16); // only digits, max 16
  this.cardNumber = input.value;
}

// CVV validation (only allow 3 digits)
onCVVInput(event: any) {
  const input = event.target;
  input.value = input.value.replace(/\D/g, '').slice(0, 3); // only digits, max 3
  this.cvv = input.value;
}

// Expiry Date validation (dd-mm-yyyy format)
onExpiryDateChange(): void {
  const regex = /^(0[1-9]|1[0-2])-\d{4}$/; // Regex to check dd-mm-yyyy format
  if (this.expiryDate && !regex.test(this.expiryDate)) {
    // Custom error message if the format is invalid
    console.log('Invalid expiry date format. Please use dd-mm-yyyy.');
  }



}
}