import { Component, OnInit } from '@angular/core';
import { UserDataService } from '../../service/user-data.service';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from '../../model/User';

@Component({
  selector: 'app-forgotpassword',
  standalone: false,
  templateUrl: './forgotpassword.component.html',
  styleUrl: './forgotpassword.component.css'
})
export class ForgotpasswordComponent implements OnInit {
  user =new User();
  user1:any;
  emailValid: boolean = true;
  isPasswordValid: boolean = true;
  accountEmail: string="";
  accountPassword: string="";
  cpass:any;

  constructor(private userDataService:UserDataService,private router:Router,private route:ActivatedRoute){}
  ngOnInit(): void {
    
  }
  updatepass(){
    console.log(this.user.email)
    this.userDataService.forgotpass(this.user.email).subscribe(
      (Response:any) => {
        this.user1 = Response
        console.log(Response)
        if (Response != null) {
          if (this.cpass == this.user.password) {
            this.userDataService.updatenewpassbyemail(this.user.email, this.user.password,this.user1).subscribe(
              (Response:any) => {
                console.log(Response)
                alert("PASSWORD SUCCESSFULLY CHANGED")
                this.router.navigate(['login'])
              }
            )
          } else {
            alert("PASSWORD AND CONFIRM PASSWORD DOES NOT MATCH")
          }

        } else {
          alert("EMAIL ID DOES NOT MATCH")

        }
      }
    )
  }
  back()
  {
    this.router.navigate(['login']);
  }
  passwordValid(event: any) {
    event.target.value = event.target.value.trim();
    var pass = event.target.value
    this.isPasswordValid = pass.match("^[a-zA-Z0-9._-]+[@|_|&|%|*|$|-][a-zA-Z0-9-]{2,5}$") ? true : false
    console.log(this.passwordValid)
  }
  emailvalid(event: any) {
    event.target.value = event.target.value.trim();
    var email = event.target.value
    this.emailValid = email.match("^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\\.[a-zA-Z.]{2,4}$") ? true : false
    console.log(this.emailValid)
  }

  }
  