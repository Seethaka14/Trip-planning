import { Component } from '@angular/core';

@Component({
  selector: 'app-adminoperations',
  standalone: false,
  templateUrl: './adminoperations.component.html',
  styleUrl: './adminoperations.component.css'
})
export class AdminoperationsComponent {

}
