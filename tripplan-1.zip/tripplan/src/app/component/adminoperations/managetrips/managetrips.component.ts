import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TripserviceService } from '../../../service/tripservice.service';
import { Trip } from '../../../model/trip';
@Component({
  selector: 'app-managetrips',
  standalone: false,
  templateUrl: './managetrips.component.html',
  styleUrl: './managetrips.component.css'
})
export class ManagetripsComponent implements OnInit{

  trip=new Trip();
  tripId:any;
  sblock:boolean=false;
  trips:any;
  constructor(private router:Router,private tripService:TripserviceService){}
ngOnInit(): void {
  this.tripService.getTrips().subscribe(
    (data:any)=>{
      this.trips=data;
    }
  )
}

addTrip(): void {
  this.router.navigate(['addtrip']);
}
viewTrip(tripId:any){
  this.tripService.getTripById(tripId).subscribe(
    (Response:any)=>{
      if(Response!=null)
        this.sblock=true;
      this.trip=Response;
      this.tripId=tripId;
    }
  )

}
editTrip(tripId:any){
  this.router.navigate(['updatetrip',tripId])

}
deleteTrip(tripId:any){
    this.tripService.removeTripById(tripId).subscribe(
      (response:any)=>{
        this.trips=response;
      }
    );
  }
  backToAdminHome(): void {
    const adminName = localStorage.getItem('adminName') || '';
    this.router.navigate(['/adminhome', adminName]);
  }
}


