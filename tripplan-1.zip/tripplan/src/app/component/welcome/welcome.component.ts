import { Component, OnInit } from '@angular/core';
import { User } from '../../model/User';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from '../../service/login.service';

@Component({
  selector: 'app-welcome',
  standalone: false,
  templateUrl: './welcome.component.html',
  styleUrl: './welcome.component.css'
})
export class WelcomeComponent implements OnInit {
userEmail!:string;
userPassword!:string;
userId:any;
user=new User();
constructor(private loginService:LoginService,private router:Router,private route:ActivatedRoute){}
ngOnInit(): void {
  
}
loginUser(){
  if (!this.user.email || !this.user.password) {
    alert("YOU CANNOT LEAVE USERNAME OR PASSWORD AS EMPTY");
    return;
  }

  this.loginService.loginvalidation(this.user).subscribe(
    (response: any) => {
      if (response == null) {
        alert("USERNAME OR PASSWORD IS INCORRECT");
      } else {
        this.userId = Object.values(response)[0];
        console.log(this.userId);
        sessionStorage.setItem('userId', this.userId);
        sessionStorage.setItem('firstName', response.firstName);
        sessionStorage.setItem('lastName', response.lastName);
        alert("Login Successfully");
        this.router.navigate(['home']);

      }
    },
    (error) => {
      alert("Login failed, try again");
      console.error(error);
    }
  );
}
forgotpassword() {
  this.router.navigate(['forgotpassword']);
}

createaccount(){
  console.log(this.createaccount);
  this.router.navigate(['createaccount']);
}

}


