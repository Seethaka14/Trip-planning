import { TestBed } from '@angular/core/testing';

import { TripcategoryserviceService } from './tripcategoryservice.service';

describe('TripcategoryserviceService', () => {
  let service: TripcategoryserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TripcategoryserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
