import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TouristserviceService implements OnInit{


  constructor(private http:HttpClient) { }
  url="http://localhost:8084/api/tourist"
  ngOnInit(): void {
    
  }
  addTourist(tourist:any){
    return this.http.post(`${this.url}`,tourist)
  }
  addTouristToTrip(tripId:any,tourist:any){
    return this.http.post(`${this.url}/addTouristtoTrip/${tripId}`,tourist)
  }

  getAllTourists(){
    return this.http.get(`${this.url}`)
  }
}
