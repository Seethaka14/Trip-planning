import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Wishlist } from '../model/wishlist';
@Injectable({
  providedIn: 'root'
})
export class WishlistserviceService implements OnInit {
 
  url = 'http://localhost:8084/api/wishlists'
  constructor(private http:HttpClient) { }
  ngOnInit(): void {
    
  }
  // Create new wishlist
  createWishlist(wishlist:any) {
    return this.http.post(`${this.url}`, wishlist);
  }

  // Get all wishlists
  getAllWishlists() {
  return this.http.get(`${this.url}`);
  }

  // Get wishlist by ID
  getWishlistByUserId(id: number): Observable<Wishlist> {
    return this.http.get<Wishlist>(`${this.url}/${id}`);
  }

  // Update wishlist
  updateWishlist(id: number, wishlist: Wishlist): Observable<Wishlist> {
    return this.http.put<Wishlist>(`${this.url}/update/${id}`, wishlist);
  }

  // Delete wishlist
  deleteWishlist(id: number): Observable<void> {
    return this.http.delete<void>(`${this.url}/delete/${id}`);
  }

  // Get wishlist by user ID
  getWishlistsByUserId(userId: number): Observable<Wishlist[]> {
    return this.http.get<Wishlist[]>(`${this.url}/user/${userId}`);
  }
}


