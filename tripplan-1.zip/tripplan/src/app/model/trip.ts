import { Transportation } from "./Transportation";
export class Trip{
    tripId:number|null;
    trip_type:string;
    source: string;
  destination: string;
  budget: number;
  trip_startDate: string;
  trip_endDate: string;
  description: string;
  tranportationMode:string;
  No_ofDays: number;
  constructor(){
    this.tripId=null;
    this.trip_type="";
    this.source="";
    this.destination="";
    this.budget=0;
    this.trip_startDate="";
    this.trip_endDate="";
    this.description="";
    this.No_ofDays=0;
    this.tranportationMode="";

  }
}