export class User{
    userId:number|null;
    firstName:string;
    lastName:string;
    userAge:number;
    userGender:string;
    address:string;
    password:string;
    email:string;
    userMobileNo:string;
    userFavourite:String;
    
constructor(){
    this.userId=null;
    this.firstName="";
    this.lastName="";
    this.userAge=0;
    this.userGender="";
    this.password="";
    this.email="";
    this.userMobileNo="";
    this.address="";
    this.userFavourite="";
    
}
}