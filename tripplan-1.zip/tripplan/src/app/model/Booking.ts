export class Booking{
    bookingId:number|null;
    bookingReference:string;
    bookingDate:string;
    status:string;

    constructor(){
        this.bookingId=null;
        this.bookingReference="";
        this.bookingDate="";
        this.status="";
    }
}